package oauth.signpost.mocks;

public interface OAuthProviderMock {

    void mockConnection(String responseBody) throws Exception;

}
